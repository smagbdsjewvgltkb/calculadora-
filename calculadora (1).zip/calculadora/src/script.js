const loginContainer = document.getElementById("login-container");
const calculatorContainer = document.getElementById("calculator-container");
const display = document.getElementById("display");
const errorMessage = document.getElementById("error-message");

// Manejo del Login
document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // Usuario: admin, Contraseña: admin123
  if (username === "admin" && password === "admin123") {
    loginContainer.style.display = "none";
    calculatorContainer.style.display = "block";
  } else {
    errorMessage.textContent = "Usuario o contraseña incorrectos";
  }
});

// Cerrar Sesión
document.getElementById("logout").addEventListener("click", function () {
  loginContainer.style.display = "block";
  calculatorContainer.style.display = "none";
  document.getElementById("username").value = "";
  document.getElementById("password").value = "";
  errorMessage.textContent = "";
});

// Funciones de la Calculadora
function appendCharacter(character) {
  display.value += character;
}

function deleteLast() {
  display.value = display.value.slice(0, -1);
}

function clearDisplay() {
  display.value = "";
}

function calculateResult() {
  try {
    display.value = eval(display.value);
  } catch (error) {
    display.value = "Error";
  }
}
